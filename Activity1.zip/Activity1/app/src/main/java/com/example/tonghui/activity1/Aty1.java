package com.example.tonghui.activity1;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by tonghui on 2017/9/20.
 */

public class Aty1 extends Activity {
    private Button btnClose;
    private TextView tvOut;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty1);
        btnClose = (Button) findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        }
        );
        tvOut = (TextView) findViewById(R.id.tvOut);
       // tvOut.setText(getIntent().getStringExtra("txt"));
        Bundle data = getIntent().getExtras();
        String txt = data.getString("txt");
        tvOut.setText(txt);
    }
}
