package com.coder520.user.controller;

import com.coder520.user.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("user")
public class UserController {
    @RequestMapping("/index")
    public String user(){
        User user = new User();
        user.setMobile("123123213");
        user.setRealname("laowang");
        return "user";
    }
}