package com.example.tonghui.usingservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.sql.SQLOutput;

/**
 * Created by tonghui on 2017/9/21.
 */

public class EcoService extends Service {

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
       return null;
    }

    @Override
    public void onCreate() {
        System.out.println("Create");
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        System.out.println("Destroy");
        super.onDestroy();
    }
}
